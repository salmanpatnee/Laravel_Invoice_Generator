<!DOCTYPE html>
<html lang="en">

<head>
    <title><?php echo e($invoice->name); ?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <link rel="stylesheet" href="<?php echo e(public_path('vendor/invoices/bootstrap.min.css')); ?>">

    <style type="text/css" media="screen">
        * {
            font-family: "DejaVu Sans";
        }

        html {
            margin: 0;
        }

        body {
            font-size: 10px;
            margin: 36pt;
        }

        body,
        h1,
        h2,
        h3,
        h4,
        h5,
        h6,
        table,
        th,
        tr,
        td,
        p,
        div {
            line-height: 1.1;
        }

        .party-header {
            font-size: 1.5rem;
            font-weight: 400;
        }

        .total-amount {
            font-size: 12px;
            font-weight: 700;
        }

    </style>
</head>

<body>



    <table class="table mt-5" width="100%">
        <tbody>
            <tr>
                <td width="100%" style="text-align:center;" class="border-0 pl-0">
                    <?php if($invoice->logo): ?>
                        <img src="<?php echo e($invoice->getLogo()); ?>" alt="logo" height="100">
                    <?php endif; ?>
                </td>
            </tr>
            
        </tbody>
    </table>
    <hr style="margin:1em 0; border-top:1px solid #F0F3FD;">
    <table class="table mt-5" width="100%">
        <tbody>
            <tr>
                <td width="50%" class="border-0 pl-0">

                    <p style="font-size: 16px;"><?php echo e(__('invoices::invoice.date')); ?>:
                        <strong><?php echo e($invoice->getDate()); ?></strong>
                    </p>
                </td>
                <td width=" 50%" class="border-0 pl-0">
                    <p style="font-size: 16px; text-align:right;"><?php echo e(__('invoices::invoice.serial')); ?>

                        <strong><?php echo e($invoice->getSerialNumber()); ?></strong>
                    </p>

                </td>
            </tr>
        </tbody>
    </table>
    <hr style="margin:1em 0; border-top:1px solid #F0F3FD;">

    <table style="margin-top:30px; margin-bottom:30px;" class="table">
        <thead>
            <tr>
                <th class="border-0 pl-0 party-header" width="50%" style="text-align: left; font-size:14px;">
                    Invoiced To:
                </th>
            </tr>
            <tr>
                <td>
                    <?php if($invoice->buyer->name): ?>
                        <p class="buyer-name">
                            Name: <?php echo e($invoice->buyer->name); ?>

                        </p>
                    <?php endif; ?>

                    <?php if($invoice->buyer->address): ?>
                        <p class="buyer-address">
                            <?php echo e(__('invoices::invoice.address')); ?>: <?php echo e($invoice->buyer->address); ?>

                        </p>
                    <?php endif; ?>

                    <?php if($invoice->buyer->code): ?>
                        <p class="buyer-code">
                            <?php echo e(__('invoices::invoice.code')); ?>: <?php echo e($invoice->buyer->code); ?>

                        </p>
                    <?php endif; ?>

                    <?php if($invoice->buyer->vat): ?>
                        <p class="buyer-vat">
                            <?php echo e(__('invoices::invoice.vat')); ?>: <?php echo e($invoice->buyer->vat); ?>

                        </p>
                    <?php endif; ?>

                    <?php if($invoice->buyer->phone): ?>
                        <p class="buyer-phone">
                            <?php echo e(__('invoices::invoice.phone')); ?>: <?php echo e($invoice->buyer->phone); ?>

                        </p>
                    <?php endif; ?>

                    <?php $__currentLoopData = $invoice->buyer->custom_fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="buyer-custom-field">
                            <?php echo e(ucfirst($key)); ?>: <?php echo e($value); ?>

                        </p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
            </tr>
        </thead>

    </table>

    
    <table class="table" width="100%">
        <thead style="background-color: #f0f3fd; height:30px">
            <tr>
                <th style="padding:20px" scope="col" class="border-0 pl-0"><?php echo e(__('invoices::invoice.description')); ?>

                </th>
                <?php if($invoice->hasItemUnits): ?>
                    <th scope="col" class="text-center border-0"><?php echo e(__('invoices::invoice.units')); ?></th>
                <?php endif; ?>
                <th scope="col" class="text-center border-0"><?php echo e(__('invoices::invoice.quantity')); ?></th>
                <th scope="col" class="text-right border-0"><?php echo e(__('invoices::invoice.price')); ?></th>
                <?php if($invoice->hasItemDiscount): ?>
                    <th scope="col" class="text-right border-0"><?php echo e(__('invoices::invoice.discount')); ?></th>
                <?php endif; ?>
                <?php if($invoice->hasItemTax): ?>
                    <th scope="col" class="text-right border-0"><?php echo e(__('invoices::invoice.tax')); ?></th>
                <?php endif; ?>
                <th scope="col" class="text-right border-0 pr-0"><?php echo e(__('invoices::invoice.sub_total')); ?></th>
            </tr>
        </thead>
        <tbody>
            
            <?php $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="border-bottom:1px solid #ccc; padding:10px;" class="pl-0"><?php echo e($item->title); ?>

                    </td>
                    <?php if($invoice->hasItemUnits): ?>
                        <td class="text-center"><?php echo e($item->units); ?></td>
                    <?php endif; ?>
                    <td style="border-bottom:1px solid #ccc; padding:10px; text-align:center;" class="text-center">
                        <?php echo e($item->quantity); ?></td>
                    <td style="border-bottom:1px solid #ccc; padding:10px; text-align:center;" class="text-right">
                        <?php echo e($invoice->formatCurrency($item->price_per_unit)); ?>

                    </td>
                    <?php if($invoice->hasItemDiscount): ?>
                        <td style="border-bottom:1px solid #ccc; padding:10px; text-align:center;"
                            class="text-right">
                            <?php echo e($invoice->formatCurrency($item->discount)); ?>

                        </td>
                    <?php endif; ?>
                    <?php if($invoice->hasItemTax): ?>
                        <td style="border-bottom:1px solid #ccc; padding:10px; text-align:center;"
                            class="text-right">
                            <?php echo e($invoice->formatCurrency($item->tax)); ?>

                        </td>
                    <?php endif; ?>

                    <td style="border-bottom:1px solid #ccc; padding:10px; text-align:center;" class="text-right pr-0">
                        <?php echo e($invoice->formatCurrency($item->sub_total_price)); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php if($invoice->hasItemOrInvoiceDiscount()): ?>
                <tr>
                    <td colspan="<?php echo e($invoice->table_columns - 2); ?>" class="border-0"></td>
                    <td class="text-right pl-0"><?php echo e(__('invoices::invoice.total_discount')); ?></td>
                    <td class="text-right pr-0">
                        <?php echo e($invoice->formatCurrency($invoice->total_discount)); ?>

                    </td>
                </tr>
            <?php endif; ?>
            <?php if($invoice->taxable_amount): ?>
                <tr>
                    <td colspan="<?php echo e($invoice->table_columns - 2); ?>" class="border-0"></td>
                    <td class="text-right pl-0"><?php echo e(__('invoices::invoice.taxable_amount')); ?></td>
                    <td class="text-right pr-0">
                        <?php echo e($invoice->formatCurrency($invoice->taxable_amount)); ?>

                    </td>
                </tr>
            <?php endif; ?>
            <?php if($invoice->tax_rate): ?>
                <tr>
                    <td colspan="<?php echo e($invoice->table_columns - 2); ?>" class="border-0"></td>
                    <td class="text-right pl-0"><?php echo e(__('invoices::invoice.tax_rate')); ?></td>
                    <td class="text-right pr-0">
                        <?php echo e($invoice->tax_rate); ?>%
                    </td>
                </tr>
            <?php endif; ?>
            <?php if($invoice->hasItemOrInvoiceTax()): ?>
                <tr>
                    <td colspan="<?php echo e($invoice->table_columns - 2); ?>" class="border-0"></td>
                    <td class="text-right pl-0"><?php echo e(__('invoices::invoice.total_taxes')); ?></td>
                    <td class="text-right pr-0">
                        <?php echo e($invoice->formatCurrency($invoice->total_taxes)); ?>

                    </td>
                </tr>
            <?php endif; ?>
            <?php if($invoice->shipping_amount): ?>
                <tr>
                    <td colspan="<?php echo e($invoice->table_columns - 2); ?>" class="border-0"></td>
                    <td class="text-right pl-0"><?php echo e(__('invoices::invoice.shipping')); ?></td>
                    <td class="text-right pr-0">
                        <?php echo e($invoice->formatCurrency($invoice->shipping_amount)); ?>

                    </td>
                </tr>
            <?php endif; ?>
            <tr>
                <td colspan="<?php echo e($invoice->table_columns - 2); ?>" class="border-0"></td>
                <td style="background-color: #f0f3fd; height:30px; text-align:center;" class="text-right pl-0">
                    <?php echo e(__('invoices::invoice.total_amount')); ?></td>
                <td style="background-color: #f0f3fd; height:30px; text-align:center;"
                    class="text-right pr-0 total-amount">
                    <?php echo e($invoice->formatCurrency($invoice->total_amount)); ?>

                </td>
            </tr>
        </tbody>
    </table>

    <?php if($invoice->notes): ?>
        <p>
            <?php echo e(trans('invoices::invoice.notes')); ?>: <?php echo $invoice->notes; ?>

        </p>
    <?php endif; ?>

    <script type="text/php">
        if (isset($pdf) && $PAGE_COUNT > 1) {
                                                                                                                                                                                                                                                                                                $text = "Page {PAGE_NUM} / {PAGE_COUNT}";
                                                                                                                                                                                                                                                                                                $size = 10;
                                                                                                                                                                                                                                                                                                $font = $fontMetrics->getFont("Verdana");
                                                                                                                                                                                                                                                                                                $width = $fontMetrics->get_text_width($text, $font, $size) / 2;
                                                                                                                                                                                                                                                                                                $x = ($pdf->get_width() - $width);
                                                                                                                                                                                                                                                                                                $y = $pdf->get_height() - 35;
                                                                                                                                                                                                                                                                                                $pdf->page_text($x, $y, $text, $font, $size);
                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                        
                                                        </script>
</body>

</html>
<?php /**PATH /home/u486559698/public_html/invoice/resources/views/vendor/invoices/templates/default.blade.php ENDPATH**/ ?>