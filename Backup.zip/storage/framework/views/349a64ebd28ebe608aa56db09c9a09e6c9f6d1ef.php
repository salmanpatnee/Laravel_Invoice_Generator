<div class="hidden sm:block">
    <div class="py-8">
        <div class="border-t border-gray-200"></div>
    </div>
</div>
<?php /**PATH /home/u486559698/public_html/invoice/resources/views/vendor/jetstream/components/section-border.blade.php ENDPATH**/ ?>