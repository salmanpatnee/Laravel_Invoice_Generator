<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="d-flex align-items-center justify-content-between">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('Invoices')); ?>

            </h2>
            <a href="<?php echo e(route('invoices.create')); ?>"
                class="inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition">Create
                New</a>
        </div>

     <?php $__env->endSlot(); ?>

    <div class="container">



        <div class="row">
            <div class="col-md-12">
                <?php if(count($invoices)): ?>

                    <table class="table table-striped mt-5">
                        <thead>
                            <tr>
                                <th scope="col">S.No</th>
                                <th scope="col">RM Name</th>
                                <th scope="col">Package</th>
                                <th scope="col">Brand</th>
                                <th scope="col">Client Name</th>
                                <th scope="col">Client Email</th>
                                <!--<th scope="col">Action</th>-->
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th><?php echo e($invoice->invoice_no); ?></th>
                                    <td>
                                        <?php echo e($invoice->seller->name); ?> <b>(<?php echo e($invoice->seller->code); ?>)</b>
                                    </td>
                                    <td>
                                        <?php if($invoice->is_customized): ?>
                                            Customized Package <b>(<?php echo e($invoice->FormattedCustomizedPrice); ?>)</b>
                                        <?php else: ?>
                                            <?php echo e($invoice->package->name); ?> <b>($<?php echo e($invoice->package->formattedPrice); ?>)</b>
                                        <?php endif; ?>

                                    </td>
                                    <td>
                                        <?php echo e($invoice->brand->name); ?>

                                    </td>
                                    <td>
                                        <?php echo e($invoice->client_name); ?>

                                    </td>
                                    <td>
                                        <?php echo e($invoice->client_email); ?>

                                    </td>
                                    <!--<td>-->
                                    <!--    <a href="<?php echo e(asset('storage/'.$invoice->pdf_path)); ?>" target="_blank"-->
                                    <!--        class="btn btn-danger btn-sm">-->
                                    <!--        <i class="fa fa-file-pdf-o" aria-hidden="true"></i>-->
                                    <!--    </a>-->
                                    <!--</td>-->
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($invoices->links()); ?>

                <?php else: ?>

                <?php endif; ?>

            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH /home/u486559698/public_html/invoice/resources/views/invoices/index.blade.php ENDPATH**/ ?>