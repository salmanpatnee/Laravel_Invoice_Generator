<a href="/">
    <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo">
</a>
<?php /**PATH /home/u486559698/public_html/invoice/resources/views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>